package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object University_Canberra_URL
     
    /**
     * <p></p>
     */
    public static Object Education_Level
     
    /**
     * <p></p>
     */
    public static Object University_RMIT
     
    /**
     * <p></p>
     */
    public static Object University_VC
     
    /**
     * <p></p>
     */
    public static Object University_Deakin_URL
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters(), selectedVariables)
    
            University_Canberra_URL = selectedVariables['University_Canberra_URL']
            Education_Level = selectedVariables['Education_Level']
            University_RMIT = selectedVariables['University_RMIT']
            University_VC = selectedVariables['University_VC']
            University_Deakin_URL = selectedVariables['University_Deakin_URL']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
